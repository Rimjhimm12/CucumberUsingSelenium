package cucumber.runner;

abstract class AbstractEventBus extends AbstractEventPublisher implements EventBus {

}
