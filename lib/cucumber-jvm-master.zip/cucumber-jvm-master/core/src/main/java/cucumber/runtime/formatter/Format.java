package cucumber.runtime.formatter;

public interface Format {
    String text(String text);
}
