package cucumber.runtime;

public interface GlueSupplier {
    Glue get();
}
