package cucumber.runtime.formatter;

import cucumber.api.StepDefinitionReporter;
import cucumber.runtime.StepDefinition;

public class AnyStepDefinitionReporter implements StepDefinitionReporter {

    public AnyStepDefinitionReporter() {
        // TODO Auto-generated constructor stub
    }

    @Override
    public void stepDefinition(StepDefinition stepDefinition) {
        // TODO Auto-generated method stub
    }

}
