package cucumber.runtime.java.incorrectlysubclassedstepdefs;

import cucumber.runtime.java.stepdefs.Stepdefs;

public class SubclassesStepdefs extends Stepdefs {
}
