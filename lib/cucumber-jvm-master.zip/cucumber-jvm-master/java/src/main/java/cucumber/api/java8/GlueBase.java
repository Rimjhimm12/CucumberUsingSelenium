package cucumber.api.java8;

public interface GlueBase {
}
