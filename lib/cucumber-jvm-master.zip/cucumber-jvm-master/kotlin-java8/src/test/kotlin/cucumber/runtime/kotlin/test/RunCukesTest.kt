package cucumber.runtime.kotlin.test

import cucumber.api.junit.Cucumber
import org.junit.runner.RunWith

@RunWith(Cucumber::class)
class RunCukesTest {
}
