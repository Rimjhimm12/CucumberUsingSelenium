Java 8 Bindings for Kotlin
==========================

This module only runs tests.

You can use `cucumber-java` or `cucumber-java8` directly in Kotlin.
